
  # Cyton AI Library Website

  This is a code bundle for Cyton AI Library Website. The original project is available at https://www.figma.com/design/AKGCMtghBedwMvkEFKHBp7/Cyton-AI-Library-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  