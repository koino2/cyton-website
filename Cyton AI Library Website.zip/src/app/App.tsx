import { Hero } from "./components/hero";
import { Features } from "./components/features";
import { CodeExample } from "./components/code-example";
import { NetworkTypes } from "./components/network-types";
import { GettingStarted } from "./components/getting-started";
import { Footer } from "./components/footer";
import { ThemeProvider } from "./components/theme-provider";
import { Navbar } from "./components/navbar";
import { ScrollToTop } from "./components/scroll-to-top";

export default function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
        <Hero />
        <Features />
        <CodeExample />
        <NetworkTypes />
        <GettingStarted />
        <Footer />
        <ScrollToTop />
      </div>
    </ThemeProvider>
  );
}