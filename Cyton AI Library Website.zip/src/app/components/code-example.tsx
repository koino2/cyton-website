import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { motion } from "motion/react";

const codeExample = `// Create a simple neural network
Network network = new Network.Builder()
    .addLayer(new DenseLayer(784, 128))
    .addLayer(new ActivationLayer(Activation.RELU))
    .addLayer(new DenseLayer(128, 64))
    .addLayer(new ActivationLayer(Activation.RELU))
    .addLayer(new DenseLayer(64, 10))
    .addLayer(new ActivationLayer(Activation.SOFTMAX))
    .build();

// Train the network
Trainer trainer = new Trainer(network);
trainer.setLearningRate(0.001);
trainer.setOptimizer(Optimizer.ADAM);
trainer.train(trainingData, epochs);

// Make predictions
Matrix input = new Matrix(testData);
Matrix predictions = network.predict(input);`;

const llmExample = `// Initialize a Large Language Model
LLM model = new LLM.Builder()
    .setModelType(ModelType.TRANSFORMER)
    .setVocabSize(50000)
    .setEmbeddingDim(512)
    .setNumLayers(12)
    .setNumHeads(8)
    .build();

// Generate text
String prompt = "The future of AI is";
String generated = model.generate(
    prompt, 
    maxTokens: 100,
    temperature: 0.7
);`;

export function CodeExample() {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<"network" | "llm">("network");

  const handleCopy = async (code: string, index: number) => {
    await navigator.clipboard.writeText(code);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <section id="examples" className="py-20 md:py-32">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl mb-4">
            Simple, Intuitive API
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Get started quickly with clean, readable Java code
          </p>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="max-w-4xl mx-auto"
        >
          {/* Tab Buttons */}
          <div className="flex gap-2 mb-4">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveTab("network")}
              className={`px-6 py-3 rounded-lg transition-colors ${
                activeTab === "network"
                  ? "bg-gradient-to-r from-[#1e3a8a] to-[#4c1d95] text-white"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
            >
              Neural Network
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveTab("llm")}
              className={`px-6 py-3 rounded-lg transition-colors ${
                activeTab === "llm"
                  ? "bg-gradient-to-r from-[#1e3a8a] to-[#4c1d95] text-white"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
            >
              Large Language Model
            </motion.button>
          </div>

          {/* Code Block */}
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
            className="relative bg-[#1e1e1e] rounded-xl overflow-hidden border border-border"
          >
            <div className="flex items-center justify-between px-6 py-3 border-b border-gray-700">
              <span className="text-sm text-gray-400">
                {activeTab === "network" ? "NetworkExample.java" : "LLMExample.java"}
              </span>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleCopy(activeTab === "network" ? codeExample : llmExample, activeTab === "network" ? 0 : 1)}
                className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"
              >
                {copiedIndex === (activeTab === "network" ? 0 : 1) ? (
                  <>
                    <Check className="w-4 h-4" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    Copy
                  </>
                )}
              </motion.button>
            </div>
            <div className="p-6 overflow-x-auto">
              <pre className="text-sm text-gray-300">
                <code>{activeTab === "network" ? codeExample : llmExample}</code>
              </pre>
            </div>
          </motion.div>

          {/* Installation */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mt-8 bg-muted/50 rounded-xl p-6 border border-border"
          >
            <h3 className="text-lg mb-4">Installation</h3>
            <p className="text-muted-foreground mb-4">
              Simply extract the Cyton AI folder and add it to your project directory. No complex setup required!
            </p>
            <div className="relative">
              <div className="bg-[#1e1e1e] rounded-lg p-4 pr-12">
                <code className="text-sm text-gray-300">
                  1. Download and extract cyton-ai.zip<br />
                  2. Copy the extracted folder to your project<br />
                  3. Import in your Java files:<br />
                  &nbsp;&nbsp;&nbsp;import cyton.*;<br />
                  4. Start building!
                </code>
              </div>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => handleCopy(
                  `1. Download and extract cyton-ai.zip\n2. Copy the extracted folder to your project\n3. Import in your Java files:\n   import cyton.*;\n4. Start building!`,
                  2
                )}
                className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
              >
                {copiedIndex === 2 ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}