import { Brain, Network, GitBranch, Repeat, Sparkles, Grid3x3, BarChart3, Boxes } from "lucide-react";
import { motion } from "motion/react";

const networkTypes = [
  {
    icon: Brain,
    name: "Multi-Layer Perceptron (MLP)",
    description: "Fully connected feedforward neural networks with customizable depth and width",
  },
  {
    icon: Sparkles,
    name: "Large Language Models (LLM)",
    description: "Transformer-based models for natural language processing and generation",
  },
  {
    icon: Grid3x3,
    name: "Convolutional Neural Networks (CNN)",
    description: "Specialized networks for image and spatial data processing",
  },
  {
    icon: Repeat,
    name: "Recurrent Neural Networks (RNN)",
    description: "Networks with memory for sequential and time-series data",
  },
  {
    icon: GitBranch,
    name: "Long Short-Term Memory (LSTM)",
    description: "Advanced RNN variant for learning long-term dependencies",
  },
  {
    icon: Network,
    name: "Generative Adversarial Networks (GAN)",
    description: "Dual network architecture for generative modeling",
  },
  {
    icon: BarChart3,
    name: "Autoencoders",
    description: "Unsupervised learning for dimensionality reduction and feature learning",
  },
  {
    icon: Boxes,
    name: "Custom Architectures",
    description: "Build your own network types with flexible layer composition",
  },
];

export function NetworkTypes() {
  return (
    <section id="networks" className="py-20 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl mb-4">
            Supported Network Architectures
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            From simple MLPs to advanced LLMs, Cyton AI supports a wide range of neural network types
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {networkTypes.map((network, index) => {
            const Icon = network.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                whileHover={{ scale: 1.05, y: -5 }}
                className="bg-background border border-border rounded-xl p-6 hover:shadow-lg hover:border-[#4c1d95]/30 transition-all group"
              >
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="w-12 h-12 bg-gradient-to-br from-[#1e3a8a]/10 to-[#4c1d95]/10 rounded-lg flex items-center justify-center mb-4 group-hover:from-[#1e3a8a]/20 group-hover:to-[#4c1d95]/20 transition-colors"
                >
                  <Icon className="w-6 h-6 text-[#4c1d95]" />
                </motion.div>
                <h3 className="mb-2">{network.name}</h3>
                <p className="text-sm text-muted-foreground">{network.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}