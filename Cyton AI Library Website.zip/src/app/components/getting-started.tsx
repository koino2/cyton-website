import { Download, BookOpen, Code, Rocket } from "lucide-react";
import { motion } from "motion/react";

const steps = [
  {
    icon: Download,
    title: "Download Cyton AI",
    description: "Download and extract the Cyton AI library",
    code: `// Download cyton-ai.zip
// Extract to your preferred location`,
  },
  {
    icon: Code,
    title: "Add to Your Project",
    description: "Copy the extracted folder into your Java project directory",
    code: `// Project structure:
MyProject/
  ├── src/
  ├── cyton/          ← Add here
  └── lib/`,
  },
  {
    icon: Rocket,
    title: "Import and Build",
    description: "Import Cyton AI in your Java files and start creating networks",
    code: `import cyton.*;

Network network = new Network.Builder()
    .addLayer(new DenseLayer(784, 128))
    .addLayer(new ActivationLayer(Activation.RELU))
    .build();`,
  },
  {
    icon: BookOpen,
    title: "Explore & Learn",
    description: "Check out examples and documentation for advanced features",
    code: `// Visit documentation for:
// - Training strategies
// - Custom layers
// - Model optimization
// - Deployment guides`,
  },
];

export function GettingStarted() {
  return (
    <section id="docs" className="py-20 md:py-32">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl mb-4">
            Get Started in Minutes
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Follow these simple steps to start building AI models with Cyton AI
          </p>
        </motion.div>
        
        <div className="max-w-5xl mx-auto space-y-12">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex flex-col md:flex-row gap-6 items-start"
              >
                {/* Step Number & Icon */}
                <div className="flex-shrink-0">
                  <motion.div
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    className="relative"
                  >
                    <div className="w-16 h-16 bg-gradient-to-br from-[#1e3a8a] to-[#4c1d95] rounded-xl flex items-center justify-center shadow-lg shadow-[#4c1d95]/30">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <motion.div
                      initial={{ scale: 0 }}
                      whileInView={{ scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.3, delay: index * 0.1 + 0.2 }}
                      className="absolute -top-2 -right-2 w-8 h-8 bg-background border-2 border-[#4c1d95] rounded-full flex items-center justify-center text-sm"
                    >
                      {index + 1}
                    </motion.div>
                  </motion.div>
                </div>

                {/* Content */}
                <div className="flex-1">
                  <h3 className="text-2xl mb-2">{step.title}</h3>
                  <p className="text-muted-foreground mb-4">{step.description}</p>
                  
                  {/* Code Block */}
                  <motion.div
                    whileHover={{ scale: 1.01 }}
                    className="bg-[#1e1e1e] rounded-lg p-4 overflow-x-auto border border-border"
                  >
                    <pre className="text-sm text-gray-300">
                      <code>{step.code}</code>
                    </pre>
                  </motion.div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center mt-16"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-gradient-to-r from-[#1e3a8a] to-[#4c1d95] text-white px-8 py-4 rounded-lg hover:shadow-lg hover:shadow-[#4c1d95]/50 transition-all"
          >
            Start Building Now
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}