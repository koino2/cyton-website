import { ArrowRight, Github, BookOpen } from "lucide-react";
import { motion } from "motion/react";
import logo from "figma:asset/871cd5e4d31d843a7fa9d9ecc4e597d3b3eb8343.png";
import { Particles } from "./particles";

export function Hero() {
  return (
    <section className="relative overflow-hidden pt-16">
      {/* Animated Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#1e3a8a] via-[#4c1d95] to-[#581c87] opacity-[0.03] dark:opacity-[0.08]" />
      
      {/* Animated Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]" />
      
      {/* Particles */}
      <Particles />
      
      {/* Floating Orbs */}
      <motion.div
        className="absolute top-20 left-10 w-72 h-72 bg-gradient-to-r from-[#1e3a8a] to-[#4c1d95] rounded-full opacity-20 blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          x: [0, 50, 0],
          y: [0, 30, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-r from-[#581c87] to-[#4c1d95] rounded-full opacity-20 blur-3xl"
        animate={{
          scale: [1, 1.3, 1],
          x: [0, -30, 0],
          y: [0, 50, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      
      <div className="container mx-auto px-4 py-20 md:py-32 relative">
        <div className="max-w-5xl mx-auto text-center">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8 flex justify-center"
          >
            <motion.img
              src={logo}
              alt="Cyton AI Logo"
              className="h-16 md:h-20 w-auto"
              whileHover={{ scale: 1.05, rotate: [0, -5, 5, 0] }}
              transition={{ duration: 0.5 }}
            />
          </motion.div>
          
          {/* Main Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-6xl mb-6"
          >
            <span className="bg-gradient-to-r from-[#1e3a8a] via-[#4c1d95] to-[#581c87] bg-clip-text text-transparent animate-gradient">
              Pure Java AI/ML Library
            </span>
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl md:text-2xl text-muted-foreground mb-4 max-w-3xl mx-auto"
          >
            Build powerful neural networks with Cyton AI - a comprehensive machine learning library written entirely in Java
          </motion.p>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto"
          >
            Support for LLMs, MLPs, and many other network architectures. No external dependencies, pure Java implementation.
          </motion.p>
          
          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group bg-gradient-to-r from-[#1e3a8a] to-[#4c1d95] text-white px-8 py-4 rounded-lg hover:shadow-lg hover:shadow-[#4c1d95]/50 transition-all flex items-center gap-2"
            >
              Get Started
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-background border-2 border-border px-8 py-4 rounded-lg hover:bg-muted transition-colors flex items-center gap-2"
            >
              <BookOpen className="w-5 h-5" />
              Documentation
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-background border-2 border-border px-8 py-4 rounded-lg hover:bg-muted transition-colors flex items-center gap-2"
            >
              <Github className="w-5 h-5" />
              View on GitHub
            </motion.button>
          </motion.div>
          
          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="grid grid-cols-3 gap-8 mt-20 max-w-2xl mx-auto"
          >
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="text-center"
            >
              <div className="text-3xl md:text-4xl bg-gradient-to-r from-[#1e3a8a] to-[#4c1d95] bg-clip-text text-transparent mb-2">
                100%
              </div>
              <div className="text-sm text-muted-foreground">Pure Java</div>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="text-center"
            >
              <div className="text-3xl md:text-4xl bg-gradient-to-r from-[#1e3a8a] to-[#4c1d95] bg-clip-text text-transparent mb-2">
                10+
              </div>
              <div className="text-sm text-muted-foreground">Network Types</div>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.1 }}
              className="text-center"
            >
              <div className="text-3xl md:text-4xl bg-gradient-to-r from-[#1e3a8a] to-[#4c1d95] bg-clip-text text-transparent mb-2">
                0
              </div>
              <div className="text-sm text-muted-foreground">Dependencies</div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}