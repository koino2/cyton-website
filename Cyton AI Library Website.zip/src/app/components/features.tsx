import { Cpu, Zap, Code2, Shield, Layers, TrendingUp } from "lucide-react";
import { motion } from "motion/react";

const features = [
  {
    icon: Code2,
    title: "Pure Java Implementation",
    description: "Written entirely in Java with zero external dependencies. Works seamlessly in any Java environment.",
  },
  {
    icon: Cpu,
    title: "LLM Support",
    description: "Built-in support for Large Language Models with optimized inference and training capabilities.",
  },
  {
    icon: Layers,
    title: "Multi-Layer Perceptrons",
    description: "Flexible MLP architectures with customizable layers, activation functions, and optimization strategies.",
  },
  {
    icon: Zap,
    title: "High Performance",
    description: "Optimized for speed with efficient matrix operations and parallel processing capabilities.",
  },
  {
    icon: Shield,
    title: "Type Safe",
    description: "Leverage Java's strong type system for reliable and maintainable machine learning code.",
  },
  {
    icon: TrendingUp,
    title: "Extensible Architecture",
    description: "Easily extend and customize network types, layers, and training algorithms to fit your needs.",
  },
];

export function Features() {
  return (
    <section id="features" className="py-20 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl mb-4">
            Why Choose Cyton AI?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A modern AI/ML library built with Java developers in mind
          </p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="bg-background border border-border rounded-xl p-6 hover:shadow-lg hover:shadow-[#4c1d95]/10 transition-shadow"
              >
                <motion.div
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.5 }}
                  className="w-12 h-12 bg-gradient-to-br from-[#1e3a8a] to-[#4c1d95] rounded-lg flex items-center justify-center mb-4"
                >
                  <Icon className="w-6 h-6 text-white" />
                </motion.div>
                <h3 className="text-xl mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}